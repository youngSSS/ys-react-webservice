**To delete a Cost and Usage budget**

This example deletes the specified Cost and Usage budget.

Command::

  aws budgets delete-budget --account-id 111122223333 --budget-name "Example Budget"

